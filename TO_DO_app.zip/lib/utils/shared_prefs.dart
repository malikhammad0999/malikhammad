import 'package:shared_preferences/shared_preferences.dart';

class SharedPrefs {
  static Future<void> saveTasks(List<String> tasks) async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    prefs.setStringList('tasks', tasks);
  }

  static Future<List<String>> getTasks() async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    return prefs.getStringList('tasks') ?? [];
  }
}
